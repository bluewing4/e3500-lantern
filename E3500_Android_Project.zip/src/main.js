import { BleClient } from '@capacitor-community/bluetooth-le';
import { Capacitor } from '@capacitor/core';

/* ===== E3500 BLE 프로토콜 (BluePanel APK 분석 결과) =====
 명령(앱→랜턴, TX 특성에 write without response):
   A0 | 명령 | 데이터길이 | 데이터... | 12 34 56 78 | CRC8 | AF
 알림(랜턴→앱, RX 특성 notify):
   CC | 응답코드 | 데이터길이 | 데이터... | CRC8 | BA
 CRC8: 다항식 0x07, 초기값 0, 마지막 CRC·푸터를 뺀 모든 바이트 대상 */
const P={SERVICE:'6f6e7375-0001-0000-8b61-4d983bc456e1',TX:'6f6e7375-0001-1000-bbc5-8ef45d9982fd',RX:'6f6e7375-0001-2000-aab2-77f2cb228ef9'};
const C={POWER:0x03,FLASH:0x04,BREATH:0x05,BRIGHT:0x11,CCT:0x12,TSET:0x20,TCANCEL:0x21,STATUS:0xC0};
const RNG={b:[10,100],k:[1800,6500],t:[1,1439]};
function crc8(a){let c=0;for(const x of a){c^=x;for(let j=0;j<8;j++)c=(c&0x80)?(((c<<1)^7)&255):((c<<1)&255)}return c}
function encode(cmd,data=[]){const a=[0xA0,cmd,data.length,...data,0x12,0x34,0x56,0x78];a.push(crc8(a),0xAF);return new Uint8Array(a)}
const pkt={
  power:on=>encode(C.POWER,[on?1:0]),
  bright:v=>encode(C.BRIGHT,[v]),
  cct:k=>encode(C.CCT,[k>>8,k&255]),
  breath:on=>encode(C.BREATH,[on?1:0]),
  flash:on=>encode(C.FLASH,[on?1:0]),
  tset:m=>encode(C.TSET,[1,Math.floor(m/60),m%60,0]),
  tcancel:()=>encode(C.TCANCEL),
  status:()=>encode(C.STATUS)
};

const $=id=>document.getElementById(id);
const mk=()=>({on:false,b:85,k:3000,end:0,breath:false,flash:false,batt:null,mode:null,busy:false,id:null,q:Promise.resolve(),buf:[],user:false,retry:0,poll:0});
const L=[mk(),mk()];
let sel=0,sync=false;
const targets=()=>sync?[0,1]:[sel];
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const inr=(v,[a,b])=>v>=a&&v<=b;

let tt;function toast(m){const t=$('toast');t.textContent=m;t.classList.add('show');clearTimeout(tt);tt=setTimeout(()=>t.classList.remove('show'),2800)}

/* ---------- 전송 ---------- */
function send(i,bytes,label){
  const s=L[i];
  if(s.mode==='sim'){console.log('[시뮬레이션]',i+1,label,Array.from(bytes,x=>x.toString(16).padStart(2,'0')).join(' '));return}
  if(s.mode!=='ble')return;
  s.q=s.q.then(async()=>{
    try{await BleClient.writeWithoutResponse(s.id,P.SERVICE,P.TX,new DataView(bytes.buffer))}
    catch(e){console.error(e);toast('랜턴 '+(i+1)+' 명령 전송에 실패했어요')}
    await sleep(50);
  });
}
const th={};
function throttled(key,fn,ms=120){
  const t=th[key]||(th[key]={last:0,id:0});clearTimeout(t.id);const now=Date.now(),w=ms-(now-t.last);
  if(w<=0){t.last=now;fn()}else t.id=setTimeout(()=>{t.last=Date.now();fn()},w);
}
/* 연결된 대상만 골라 실행 */
function act(fn){
  const ts=targets().filter(i=>L[i].mode);
  if(!ts.length){toast('먼저 랜턴을 연결하세요');return false}
  if(sync&&ts.length<2)toast('랜턴 '+(2-ts[0])+'은 연결되지 않아 제외했어요');
  ts.forEach(fn);return true;
}

/* ---------- 알림 수신 ---------- */
function onData(i,dv){
  const s=L[i];s.buf.push(...new Uint8Array(dv.buffer,dv.byteOffset,dv.byteLength));
  for(;;){
    while(s.buf.length&&s.buf[0]!==0xCC)s.buf.shift();
    if(s.buf.length<5)return;
    const n=s.buf[2]+5;if(s.buf.length<n)return;
    const p=s.buf.slice(0,n);
    if(p[n-1]!==0xBA||crc8(p.slice(0,n-2))!==p[n-2]){s.buf.shift();continue}
    s.buf.splice(0,n);handle(i,p[1],p.slice(3,n-2));
  }
}
function handle(i,code,d){
  const s=L[i];
  switch(code){
    case 0:if(d.length===9){s.on=d[0]===1;if(d[8]<=100)s.batt=d[8]}break;       // 상태 스냅샷
    case 2:if(d.length===1)s.on=d[0]===1;break;                                  // 전원
    case 9:if(d.length===1&&d[0]<=100)s.batt=d[0];break;                         // 배터리
    case 6:if(d.length===1&&inr(d[0],RNG.b))s.b=d[0];break;                      // 밝기
    case 7:if(d.length===2){const k=d[0]<<8|d[1];if(inr(k,RNG.k))s.k=k}break;    // 색온도
    case 3:if(d.length===1)s.breath=d[0]===1;break;                              // 호흡
    case 4:if(d.length===1)s.flash=d[0]===1;break;                               // 점멸
    case 8:if(d.length===5){                                                      // 타이머
      if(d.every(x=>x===0))s.end=0;
      else if(d[0]===1&&d[1]===1)s.end=Date.now()+(d[2]*3600+d[3]*60+d[4])*1000;
    }break;
    default:console.log('[알림]',i+1,code,d);
  }
  render();
}

/* ---------- 상태 변경 ---------- */
function setPower(i,on){L[i].on=on;if(!on)L[i].end=0;send(i,pkt.power(on),'전원')}
function applyPreset(b,k){
  act(i=>{const s=L[i];if(!s.on)setPower(i,true);s.b=b;s.k=k;send(i,pkt.bright(b),'밝기');send(i,pkt.cct(k),'색온도')});render();
}
function toggleFx(kind){
  act(i=>{
    const s=L[i],on=!s[kind],other=kind==='breath'?'flash':'breath';
    if(on&&s[other]){s[other]=false;send(i,pkt[other](false),other)}
    s[kind]=on;send(i,pkt[kind](on),kind);
  });render();
}

/* ---------- 렌더링 ---------- */
function fmt(ms){const s=Math.max(0,Math.ceil(ms/1000)),h=Math.floor(s/3600),m=Math.floor(s%3600/60);return(h?h+':'+String(m).padStart(2,'0'):m)+':'+String(s%60).padStart(2,'0')}
const modeTxt=s=>s.busy?'연결 중…':s.mode==='ble'?'연결됨':s.mode==='sim'?'시뮬레이션':'미연결';
function render(){
  const s=L[sel];
  document.querySelectorAll('.tab').forEach((t,i)=>{t.setAttribute('aria-selected',i===sel);t.querySelector('.dot').classList.toggle('on',L[i].on);t.querySelector('.cs').textContent=modeTxt(L[i])});
  const c=!!s.mode;
  $('powerBox').classList.toggle('active',s.on);$('powerBox').setAttribute('aria-pressed',s.on);
  $('powerStateText').textContent=s.on?'켜짐':'꺼짐';
  $('brightnessSlider').value=s.b;$('brightnessVal').textContent=s.b+'%';
  $('cctSlider').value=s.k;$('cctVal').textContent=s.k+'K';
  const en=c&&s.on;['brightnessSlider','cctSlider'].forEach(id=>$(id).disabled=!en);
  $('offHint').textContent=c?'전원을 켜면 조절할 수 있어요':'랜턴을 먼저 연결하세요';
  $('offHint').style.display=en?'none':'block';
  const img=$('lanternImg');
  img.style.background=s.on?`rgba(255,${Math.round(150+(s.k-1800)/4700*105)},${Math.round(60+(s.k-1800)/4700*195)},${.1+s.b/100*.35})`:'#ffffff0d';
  img.style.boxShadow=s.on?`0 0 ${s.b/4}px rgba(255,210,122,${s.b/200})`:'none';
  document.querySelectorAll('.scene-btn').forEach(b=>b.classList.toggle('active',s.on&&+b.dataset.b===s.b&&+b.dataset.k===s.k));
  [['fxBreath','breath'],['fxFlash','flash']].forEach(([id,k])=>{$(id).classList.toggle('active',s[k]);$(id).setAttribute('aria-pressed',s[k])});
  $('syncDesc').textContent=sync?'랜턴 1·2를 함께 제어합니다':'선택한 랜턴만 제어합니다';
  $('batteryVal').textContent=s.batt==null?'--%':s.batt+'%';
  $('modeLabel').textContent=s.mode==='ble'?'실제 기기':s.mode==='sim'?'설정 미리보기':'미연결';
  const b=$('connectBtn');b.classList.toggle('connected',c);b.disabled=s.busy;
  $('connectText').textContent=s.busy?'연결 중…':c?'연결 해제':'연결하기';
  renderTimer();
}
function renderTimer(){
  const s=L[sel];$('timerBtn').classList.toggle('running',!!s.end);
  $('timerText').textContent=s.end?fmt(s.end-Date.now())+' 후 소등 (탭하여 변경/취소)':'자동 소등 예약';
}

/* ---------- 이벤트 ---------- */
document.querySelectorAll('.tab').forEach(t=>t.onclick=()=>{sel=+t.dataset.i;render()});
$('powerBox').onclick=()=>{const on=!L[sel].on;act(i=>setPower(i,on));render()};
$('syncToggle').onchange=e=>{
  sync=e.target.checked;
  if(sync&&L[1-sel].mode){const s=L[sel],o=1-sel;L[o].b=s.b;L[o].k=s.k;setPower(o,s.on);if(s.on){send(o,pkt.bright(s.b),'밝기');send(o,pkt.cct(s.k),'색온도')}}
  render();
};
$('brightnessSlider').oninput=e=>{const v=+e.target.value;act(i=>{L[i].b=v;throttled('b'+i,()=>send(i,pkt.bright(L[i].b),'밝기'))});render()};
$('cctSlider').oninput=e=>{const v=+e.target.value;act(i=>{L[i].k=v;throttled('k'+i,()=>send(i,pkt.cct(L[i].k),'색온도'))});render()};
document.querySelectorAll('.scene-btn').forEach(b=>b.onclick=()=>applyPreset(+b.dataset.b,+b.dataset.k));
$('fxBreath').onclick=()=>toggleFx('breath');$('fxFlash').onclick=()=>toggleFx('flash');

/* ---------- 소등 예약 (랜턴 자체 타이머) ---------- */
const dlg=$('timerDlg');let pickMin=30;
function pickChip(m){pickMin=m;document.querySelectorAll('.chip').forEach(c=>c.classList.toggle('active',+c.dataset.m===m));$('customMin').value=''}
$('timerBtn').onclick=()=>{
  if(!L[sel].mode){toast('먼저 랜턴을 연결하세요');return}
  const s=L[sel];$('timerErr').textContent='';
  $('dlgDesc').textContent=(sync?'랜턴 1·2 모두':'랜턴 '+(sel+1))+(s.end?' · 현재 '+fmt(s.end-Date.now())+' 남음':' · 몇 분 뒤에 끌까요?');
  $('dlgCancel').textContent=s.end?'예약 취소':'닫기';
  pickChip(30);dlg.showModal();
};
document.querySelectorAll('.chip').forEach(c=>c.onclick=()=>pickChip(+c.dataset.m));
$('customMin').oninput=()=>document.querySelectorAll('.chip').forEach(c=>c.classList.remove('active'));
$('dlgCancel').onclick=()=>{
  if(L[sel].end){act(i=>{L[i].end=0;send(i,pkt.tcancel(),'타이머 취소')});toast('소등 예약을 취소했어요');render()}
  dlg.close();
};
$('dlgStart').onclick=()=>{
  const raw=$('customMin').value,m=raw!==''?Number(raw):pickMin;
  if(!Number.isInteger(m)||!inr(m,RNG.t)){$('timerErr').textContent='1~1439분(23시간 59분) 사이의 정수를 입력하세요.';return}
  if(!targets().some(i=>L[i].mode&&L[i].on)){$('timerErr').textContent='랜턴이 꺼져 있어요. 먼저 전원을 켜세요.';return}
  act(i=>{L[i].end=Date.now()+m*60000;send(i,pkt.tset(m),'타이머 설정');setTimeout(()=>send(i,pkt.status(),'상태 요청'),600)});
  dlg.close();toast(m+'분 후 소등합니다');render();
};
dlg.addEventListener('click',e=>{if(e.target===dlg)dlg.close()});
setInterval(()=>{
  const now=Date.now();
  L.forEach((s,i)=>{if(s.end&&now>=s.end){s.end=0;setTimeout(()=>send(i,pkt.status(),'상태 요청'),1500)}});
  renderTimer();
},1000);

/* ---------- 연결 (랜턴마다 별도 BLE 기기 / 네이티브 BLE 플러그인) ---------- */
let inited=false,showOthers=false;
async function ensureBle(){
  if(!inited){await BleClient.initialize({androidNeverForLocation:true});inited=true}
  if(!(await BleClient.isEnabled()))await BleClient.requestEnable();
}
$('connectBtn').onclick=()=>{const i=sel,s=L[i];if(s.busy)return;s.mode?disconnect(i):connect(i)};

async function disconnect(i){
  const s=L[i];s.user=true;clearInterval(s.poll);
  if(s.mode==='ble'&&s.id){try{await BleClient.disconnect(s.id)}catch{}}
  Object.assign(s,{mode:null,end:0,batt:null,buf:[]});render();toast('랜턴 '+(i+1)+' 연결을 해제했어요');
}
async function connect(i){
  const s=L[i];
  if(!Capacitor.isNativePlatform()){s.mode='sim';render();toast('앱이 아닌 환경이라 시뮬레이션으로 동작합니다.');return}
  s.busy=true;render();
  try{
    await ensureBle();
    const id=await pickDevice();
    if(!id){s.busy=false;render();return}
    if(L[1-i].mode==='ble'&&L[1-i].id===id){toast('이미 다른 랜턴 슬롯에 연결된 기기예요');s.busy=false;render();return}
    s.id=id;s.user=false;s.retry=0;await gattConnect(i);
    toast('랜턴 '+(i+1)+' 연결했어요');
  }catch(e){
    console.error(e);s.mode=null;
    toast('연결에 실패했어요. 블루투스 권한과 랜턴 전원·거리를 확인하세요.');
  }
  s.busy=false;render();
}
async function gattConnect(i){
  const s=L[i];
  await BleClient.connect(s.id,()=>onDisc(i),{timeout:10000});
  await BleClient.startNotifications(s.id,P.SERVICE,P.RX,dv=>onData(i,dv));
  s.mode='ble';s.q=Promise.resolve();s.buf=[];
  send(i,pkt.status(),'상태 요청');                                                  // 전원·배터리·타이머 상태 수신
  clearInterval(s.poll);s.poll=setInterval(()=>send(i,pkt.status(),'상태 요청'),900000); // 15분마다 갱신
  render();
}
async function onDisc(i){
  const s=L[i];if(s.user||!s.mode)return;
  s.mode=null;render();
  while(s.retry<3&&!s.user){
    s.retry++;toast('랜턴 '+(i+1)+' 연결이 끊겼어요. 다시 연결 중… ('+s.retry+'/3)');
    await sleep(1500);
    try{await gattConnect(i);s.retry=0;toast('랜턴 '+(i+1)+' 다시 연결했어요');return}catch(e){console.error(e)}
  }
  if(!s.user)toast('랜턴 '+(i+1)+' 재연결에 실패했어요. 연결하기를 눌러 다시 시도하세요.');
}

/* ---------- 주변 랜턴 검색 목록 ---------- */
function pickDevice(){
  return new Promise(resolve=>{
    const dlg=$('scanDlg'),found=new Map();let done=false,stopT=0;
    const finish=async id=>{
      if(done)return;done=true;clearTimeout(stopT);
      try{await BleClient.stopLEScan()}catch{}
      if(dlg.open)dlg.close();resolve(id);
    };
    const draw=()=>{
      const all=[...found.values()].sort((a,b)=>b.rssi-a.rssi);
      const cands=all.filter(d=>d.cand),others=all.filter(d=>!d.cand);
      $('scanDesc').textContent='E3500 '+cands.length+'개 발견'+(others.length?' · 기타 '+others.length+'개':'');
      $('showOthers').textContent=showOthers?'기타 기기 숨기기':'기타 기기 보기';
      $('showOthers').style.display=others.length?'inline':'none';
      const box=$('devList');box.replaceChildren();
      (showOthers?all:cands).forEach(d=>{
        const b=document.createElement('button');b.type='button';b.className='dev';
        const n=document.createElement('span');n.textContent=d.name||'이름 없음';
        const m=document.createElement('small');m.textContent=d.id.slice(-5)+' · '+d.rssi+'dBm';
        b.append(n,m);b.onclick=()=>finish(d.id);box.append(b);
      });
    };
    dlg.onclose=()=>finish(null);
    $('scanClose').onclick=()=>dlg.close();
    $('showOthers').onclick=()=>{showOthers=!showOthers;draw()};
    dlg.showModal();draw();
    stopT=setTimeout(()=>{$('scanDesc').textContent='검색 시간이 끝났어요. 닫고 다시 시도하세요.';BleClient.stopLEScan().catch(()=>{})},30000);
    BleClient.requestLEScan({allowDuplicates:false},r=>{
      const name=r.localName||r.device.name||'';
      const uu=(r.uuids||[]).map(u=>u.toLowerCase());
      found.set(r.device.deviceId,{id:r.device.deviceId,name,rssi:r.rssi??-100,cand:uu.includes(P.SERVICE)||/e3500/i.test(name)});
      draw();
    }).catch(e=>{console.error(e);toast('검색을 시작하지 못했어요. 블루투스 권한을 확인하세요.');finish(null)});
  });
}
render();
