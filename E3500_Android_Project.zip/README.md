# E3500 랜턴 안드로이드 앱

Capacitor 7 기반 Android 앱 프로젝트입니다. BLE 연결은 Android 네이티브 플러그인 `@capacitor-community/bluetooth-le`을 사용합니다.

## APK 만드는 가장 쉬운 방법: GitHub Actions

1. GitHub에서 새 **Public 또는 Private 저장소**를 만듭니다.
2. 이 ZIP의 압축을 풀고 **폴더 안의 파일 전체**를 저장소 루트에 업로드합니다.
3. GitHub 저장소의 **Actions** 탭에서 `Build APK`를 선택합니다.
4. `Run workflow`를 눌러 빌드를 시작합니다. `main` 브랜치에 push해도 자동 빌드됩니다.
5. 빌드가 끝나면 실행 결과 페이지 아래 **Artifacts → E3500-lantern-debug-apk**를 내려받습니다.
6. ZIP을 풀어 `app-debug.apk`를 안드로이드 휴대폰에 설치합니다. 설치 시 브라우저/파일 앱의 '알 수 없는 앱 설치 허용'이 필요할 수 있습니다.

## PC에서 직접 빌드

필요 환경: Node.js 20 이상, JDK 21, Android SDK.

```bash
npm install
npm run android:init
cd android
./gradlew assembleDebug
```

APK 위치: `android/app/build/outputs/apk/debug/app-debug.apk`

웹 화면이나 제어 코드를 수정한 뒤에는 프로젝트 루트에서 `npm run sync`를 실행하고 다시 빌드합니다.

## 앱 구성

- 앱 이름: E3500 랜턴
- 패키지 ID: `com.e3500.lantern`
- BLE: 랜턴 검색, 연결/해제, 전원, 밝기, 색온도, 장면, 호흡/점멸, 소등 타이머, 2대 동시 제어
- Android BLE 권한: AndroidManifest에 자동 추가

## 중요

현재 프로젝트에는 E3500 BLE 서비스/특성 UUID와 명령 프레임 구현이 포함되어 있습니다. 실제 랜턴과의 최종 호환성은 설치 후 기기 연결 및 각 기능을 직접 시험해 확인해야 합니다. 이 환경에서는 Android SDK/Gradle 빌드를 실행하지 않았으므로 APK 자체가 아니라 APK 빌드용 프로젝트를 제공합니다.
